const instagram = 'https://www.instagram.com/egrip_uf/';
const layer = document.getElementById('shop-layer');
const drawer = layer.querySelector('.shop-drawer');
const form = document.getElementById('checkout-form');
const unavailable = document.getElementById('shop-unavailable');
const message = document.getElementById('shop-message');
const qtyView = document.getElementById('quantity-view');
let quantity = 1;
let product = null;
let lastFocus = null;
const formatSek = (ore) => new Intl.NumberFormat('sv-SE', {style:'currency',currency:'SEK',maximumFractionDigits:2}).format(ore / 100);
const setText = (id, content) => { document.getElementById(id).textContent = content; };
function openShop() {
  lastFocus = document.activeElement;
  layer.hidden = false;
  document.body.classList.add('modal-open');
  drawer.focus();
  syncShop();
}
function closeShop() {
  layer.hidden = true;
  document.body.classList.remove('modal-open');
  lastFocus?.focus?.();
}
document.getElementById('open-shop').addEventListener('click',openShop);
document.getElementById('close-shop').addEventListener('click',closeShop);
layer.querySelector('[data-close-shop]').addEventListener('click',closeShop);
function syncShop() {
  const priced = Number.isInteger(product?.price_ore) && product.price_ore >= 0;
  const stock = Number.isInteger(product?.stock) ? product.stock : null;
  const canPay = Boolean(priced && product?.purchaseEnabled && stock > 0 && product?.active);
  setText('shop-product-name',product?.name || 'EGrip');
  setText('shop-description',product?.description || 'Produktinformation bekräftas av EGrip.');
  setText('shop-price',priced ? formatSek(product.price_ore) : 'Pris på förfrågan');
  if (product?.image_url) {const im=layer.querySelector('.shop-product img');im.src=product.image_url;im.onerror=()=>{im.src='assets/egrip-product-reference.jpg';};}
  form.hidden = !canPay;
  unavailable.hidden = canPay;
  if(canPay){
    quantity = Math.max(1,Math.min(quantity,Math.min(10,stock)));
    qtyView.textContent = quantity;
    document.getElementById('plus-qty').disabled = quantity >= Math.min(10,stock);
    document.getElementById('minus-qty').disabled = quantity <= 1;
    document.getElementById('shop-total').textContent = formatSek(product.price_ore*quantity+(product.shipping_ore || 0));
  }
  if(!canPay && product?.price_ore !== null && product?.stock === 0){
    unavailable.querySelector('p').textContent = 'Produkten är tillfälligt slut i lager. Kontakta EGrip via Instagram för aktuell information.';
  }
}
document.getElementById('minus-qty').addEventListener('click',()=>{quantity=Math.max(1,quantity-1);syncShop();});
document.getElementById('plus-qty').addEventListener('click',()=>{quantity=Math.min(10,quantity+1);syncShop();});
form.addEventListener('submit',async event=>{
  event.preventDefault();
  if(!product?.purchaseEnabled)return;
  const pay = document.getElementById('pay-button');
  pay.disabled = true;
  message.textContent = 'Skapar säker betalning …';
  try {
    const data = Object.fromEntries(new FormData(form));
    const response = await fetch('/api/checkout', {
      method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify({...data, quantity, product_id:product.id})
    });
    const result = await response.json();
    if(!response.ok || !result.checkout_url)throw new Error(result.error || 'Betalningen kunde inte startas.');
    const target = new URL(result.checkout_url);
    if(target.protocol !== 'https:' || !target.hostname.endsWith('.stripe.com'))throw new Error('Ogiltig betalningsadress.');
    window.location.assign(target.toString());
  } catch (error) { message.textContent = error.message || 'Ett fel uppstod. Försök igen senare.';pay.disabled=false; }
});
// Cloudflare dashboard direct-upload edition: static website only.
// No backend is available here, so purchases are intentionally disabled.
// The real Cloudflare Functions + Stripe/Swish source remains in the full project ZIP.
product = {id:'egrip',name:'EGrip',description:'För pris, tillgänglighet och beställning – kontakta EGrip på Instagram.',price_ore:null,stock:null,active:false,purchaseEnabled:false};
syncShop();
const legalLayer=document.getElementById('legal-layer');
const legalContents={
  terms:{title:'Köpvillkor',content:'EGrips fullständiga köpvillkor, leveransalternativ och returinformation måste publiceras och godkännas innan webbutiken aktiveras. Kontakta EGrip via Instagram för aktuell information.'},
  privacy:{title:'Integritet',content:'EGrips integritetspolicy måste kompletteras med ansvarig organisation, kontaktvägar, lagringstider och information om vilka personuppgifter som behandlas. Aktivera inte betalningar innan detta är klart.'}
};
document.querySelectorAll('[data-legal]').forEach(button=>button.addEventListener('click',()=>{
  lastFocus=document.activeElement;
  const legal=legalContents[button.dataset.legal];
  document.getElementById('legal-title').textContent=legal.title;
  document.getElementById('legal-body').textContent=legal.content;
  legalLayer.hidden=false;document.body.classList.add('modal-open');legalLayer.querySelector('.legal-close').focus();
}));
document.querySelectorAll('[data-close-legal]').forEach(el=>el.addEventListener('click',()=>{
  legalLayer.hidden=true;document.body.classList.remove('modal-open');lastFocus?.focus?.();
}));
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){if(!layer.hidden)closeShop();if(!legalLayer.hidden){legalLayer.hidden=true;document.body.classList.remove('modal-open');lastFocus?.focus?.();}}
  if(e.key==='Tab'&&!layer.hidden){
    const focusable=Array.from(drawer.querySelectorAll('button:not([disabled]):not([hidden]),a[href]:not([hidden]),input:not([hidden])')).filter(e=>e.getClientRects().length);
    if(!focusable.length)return;
    const first=focusable[0],last=focusable[focusable.length-1];
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
    if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  }
});
const params=new URLSearchParams(location.search);
if(params.get('checkout')==='success'){
  message.textContent='Du är tillbaka från betalningen. Betalningen kontrolleras av betalningsleverantören – kontakta EGrip om du behöver hjälp.';
  openShop();
  history.replaceState({},'',location.pathname+'#order');
}else if(params.get('checkout')==='cancel'){
  message.textContent='Betalningen avbröts. Ingen betalning är bekräftad.';
  openShop();
  history.replaceState({},'',location.pathname+'#order');
}

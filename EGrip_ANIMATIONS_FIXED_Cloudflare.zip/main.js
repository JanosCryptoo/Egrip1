/* EGRIP — zero-dependency 3D WebGL + scroll choreography.
   No third-party animation libraries, CDN imports, or build process required.
   Cloudflare Pages drag-and-drop compatible. */
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const intro = $('intro'), canvas = $('scene'), packEl = $('stage-pack'), fallbackBand = $('fallback-band'), fallbackPack = $('fallback-pack');
  const fallbackCanvas=$('fallback-canvas'), fctx=fallbackCanvas.getContext('2d');
  const stage = $('webgl-stage'), fill = $('progress-fill'), num = $('chapter-number'), nav = $('site-nav');
  const inspectButton = $('inspect-toggle'), inspectHint = $('inspect-hint');
  $('year').textContent = new Date().getFullYear();
  const clamp = (v, a=0, b=1) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const ease = t => { t=clamp(t); return t*t*(3-2*t); };
  const smooth = (a,b, x) => ease((x-a)/(b-a));
  const qs = (s,root=document) => Array.from(root.querySelectorAll(s));
  const positions = [0,.15,.33,.49,.66,.82,.92,1];
  const poses = [
    { x:1.35, y: .1, rx:.12,ry:-.34,rz:-.62,scale:1.05,bend:0,zoom:11.3,pack:0 },
    { x:1.35, y:  0, rx:.02,ry:.24,rz:.15,scale:1.13,bend:0,zoom:10.9,pack:0 },
    { x:1.30, y:-.12,rx:.20,ry:.87,rz:-.25,scale:1.16,bend:.42,zoom:11.0,pack:0 },
    { x:1.34, y:-.05,rx:.13,ry:1.22,rz:.24,scale:1.18,bend:.96,zoom:10.9,pack:0 },
    { x:-1.28,y:-.1,rx:-.05,ry:-.20,rz:-.15,scale:1.85,bend:.13,zoom:10.5,pack:0 },
    { x:1.38, y:0,rx:.0,ry:.04,rz:.0,scale:1.00,bend:0,zoom:11.3,pack:1 },
    { x:1.20, y:0,rx:.06,ry:-.37,rz:-.32,scale:1.11,bend:0,zoom:11.2,pack:0 },
    { x:1.18,y:.38,rx:.12,ry:-.45,rz:-.58,scale:1.08,bend:0,zoom:11,pack:0 }
  ];
  function samplePose(t) {
    let i=positions.length-2;
    for(let j=0;j<positions.length-1;j++) if(t<=positions[j+1]){i=j;break;}
    const w=ease((t-positions[i])/(positions[i+1]-positions[i]));
    const result={};for(const k of Object.keys(poses[i]))result[k]=lerp(poses[i][k],poses[i+1][k],w);
    return result;
  }
  let progress=0, current=0, inspecting=false, dragging=false, dragY=0, dragX=0, lastPointerX=0, lastPointerY=0;
  const mobile = () => innerWidth <= 680;
  const state = {...poses[0]};
  function dismissIntro(){intro.classList.add('hidden');document.body.classList.add('ready');}
  // Never leave the site trapped behind a loading overlay, even on slow/blocked devices.
  setTimeout(dismissIntro, 1150);
  $('loader-line').style.width='100%';

  const panelElements=qs('.panel');
  const observer = new IntersectionObserver(entries => {
    for(const entry of entries){
      if (entry.isIntersecting) {
        const el=entry.target;
        el.classList.add('entered');
        el.querySelectorAll('.reveal-copy,.callout').forEach(child=>child.classList.add('in-view'));
        if(el.dataset.chapter)num.textContent=el.dataset.chapter;
      }
    }
  },{threshold:.2});
  panelElements.forEach(p=>observer.observe(p));
  const heroCopy=document.querySelector('.hero-copy');heroCopy.classList.add('in-view');
  document.body.classList.add('animations-ready');

  let gl=null, program=null, buffers=null, texture=null, webglOK=false;
  const fallback=reason=>{
    console.warn('EGrip 3D: using animated CSS fallback',reason);
    document.body.classList.add('no-webgl');
    document.body.dataset.egripReady='animated-fallback';
    if(gl && !webglOK)gl=null;
  };
  if(reduce){fallback('reduced-motion user preference');}
  else try {initWebGL();webglOK=true;document.body.dataset.egripReady='animated-webgl';}
  catch(e){fallback(e.message||e);}

  function initWebGL(){
    gl=canvas.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:false,powerPreference:'high-performance'})
        || canvas.getContext('experimental-webgl',{alpha:true,antialias:true});
    if(!gl)throw new Error('WebGL not available');
    const vertex=`
    precision highp float;
    attribute vec3 aPos;
    attribute vec3 aNormal;
    attribute vec2 aUV;
    uniform vec3 uRot;
    uniform vec3 uTranslate;
    uniform float uScale;
    uniform float uBend;
    uniform float uCamera;
    uniform float uAspect;
    uniform float uFov;
    varying vec3 vNormal;
    varying vec3 vPos;
    varying vec2 vUV;
    vec3 rot(vec3 p){
      float cx=cos(uRot.x),sx=sin(uRot.x);
      float cy=cos(uRot.y),sy=sin(uRot.y);
      float cz=cos(uRot.z),sz=sin(uRot.z);
      p=vec3(p.x,p.y*cx-p.z*sx,p.y*sx+p.z*cx);
      p=vec3(p.x*cy+p.z*sy,p.y,-p.x*sy+p.z*cy);
      p=vec3(p.x*cz-p.y*sz,p.x*sz+p.y*cz,p.z);
      return p;
    }
    void main(){
      vec3 p=aPos,n=aNormal;
      float bending=max(uBend,0.0);
      if(bending>.0001){
        float r=5.20/(6.283185*bending);
        float angle=aPos.y/r;
        float a=sin(angle),b=cos(angle);
        p.y=a*r-a*aPos.z;
        p.z=r*(1.0-b)-r*(1.0-cos(3.141593*bending))*.52+b*aPos.z;
        n=vec3(n.x,n.y*b-n.z*a,n.y*a+n.z*b);
      }
      p=rot(p)*uScale+uTranslate;
      vPos=p;
      vNormal=normalize(rot(n));
      vUV=aUV;
      float z=uCamera-p.z;
      float focal=1.0/tan(uFov*.5);
      gl_Position=vec4(p.x*focal/uAspect,p.y*focal,z*1.002-.20,z);
    }`;
    const fragment=`
    precision mediump float;
    uniform sampler2D uSurface;
    uniform float uTime;
    varying vec3 vNormal;
    varying vec3 vPos;
    varying vec2 vUV;
    void main(){
      vec3 n=normalize(vNormal);
      vec3 view=normalize(vec3(-vPos.x*.06,-vPos.y*.05,1.0));
      vec3 key=normalize(vec3(-.57,.77,1.0));
      vec3 rim=normalize(vec3(.88,.2,-.9));
      float bright=max(dot(n,key),0.0);
      float soft=max(dot(n,normalize(vec3(.5,-.85,.8))),0.0);
      float edge=pow(1.0-max(dot(n,view),0.0),2.5);
      float spec=pow(max(dot(reflect(-key,n),view),0.0),26.0);
      float other=max(dot(n,rim),0.0);
      vec4 tex=texture2D(uSurface,vUV);
      vec3 surface=tex.rgb*(.31+bright*.64+soft*.18+other*.11);
      surface+=vec3(.42)*spec+vec3(.17)*edge;
      surface*=1.04;
      gl_FragColor=vec4(surface,1.0);
    }`;
    function shader(type,source){
      const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);
      if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw new Error(gl.getShaderInfoLog(s));return s;
    }
    program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vertex));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fragment));gl.linkProgram(program);
    if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error(gl.getProgramInfoLog(program));
    gl.useProgram(program);
    buffers=createBand();
    for(const [att,size,offset] of [['aPos',3,0],['aNormal',3,12],['aUV',2,24]]){
      const loc=gl.getAttribLocation(program,att);if(loc<0)throw new Error('Missing '+att);
      gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,32,offset);
    }
    texture=gl.createTexture();gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
    gl.uniform1i(gl.getUniformLocation(program,'uSurface'),0);
    paintTexture(null);
    const logo=new Image();logo.onload=()=>paintTexture(logo);logo.src='assets/egrip-white-wordmark.png';
    gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);
    gl.disable(gl.CULL_FACE);
    resizeCanvas();
    canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();webglOK=false;fallback('WebGL context lost');});
  }
  function createBand(){
    const L=5.2,W=.91,T=.038,seg=160,cols=10, data=[];
    function push(p,n,uv){data.push(...p,...n,...uv);}
    function quad(p0,p1,p2,p3,n0,n1,n2,n3,uv0,uv1,uv2,uv3){
      push(p0,n0,uv0);push(p2,n2,uv2);push(p1,n1,uv1);
      push(p1,n1,uv1);push(p2,n2,uv2);push(p3,n3,uv3);
    }
    const N=(a,b,c)=>[a,b,c];
    const frontN=N(0,0,1),backN=N(0,0,-1),leftN=N(-1,0,0),rightN=N(1,0,0);
    for(let i=0;i<seg;i++){
      const y0=-L/2+i/seg*L,y1=-L/2+(i+1)/seg*L;
      for(let j=0;j<cols;j++){
        const x0=-W/2+j/cols*W,x1=-W/2+(j+1)/cols*W;
        const u0=j/cols,u1=(j+1)/cols,v0=i/seg,v1=(i+1)/seg;
        quad(N(x0,y0,T),N(x1,y0,T),N(x0,y1,T),N(x1,y1,T),frontN,frontN,frontN,frontN,[u0,v0],[u1,v0],[u0,v1],[u1,v1]);
        quad(N(x0,y0,-T),N(x1,y0,-T),N(x0,y1,-T),N(x1,y1,-T),backN,backN,backN,backN,[.01,v0],[.01,v0],[.01,v1],[.01,v1]);
      }
      // Thick profile visible under cinematic oblique rotation
      for(const [side,n] of [[-W/2,leftN],[W/2,rightN]]){
        quad(N(side,y0,-T),N(side,y0,T),N(side,y1,-T),N(side,y1,T),n,n,n,n,[.01,i/seg],[.01,i/seg],[.01,(i+1)/seg],[.01,(i+1)/seg]);
      }
    }
    for(const [y,ny] of [[-L/2,-1],[L/2,1]]){
      const n=N(0,ny,0);
      quad(N(-W/2,y,-T),N(W/2,y,-T),N(-W/2,y,T),N(W/2,y,T),n,n,n,n,[.01,0],[.01,0],[.01,0],[.01,0]);
    }
    const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);
    return {buffer,count:data.length/8};
  }
  function paintTexture(logo){
    const c=document.createElement('canvas');c.width=512;c.height=2048;const ctx=c.getContext('2d');
    // Photo-inspired cool grey, refined fine-grain texture.
    ctx.fillStyle='#b0b1b1';ctx.fillRect(0,0,c.width,c.height);
    let seed=85739;function rng(){seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;}
    for(let i=0;i<38000;i++){
      const shade=(rng()>.5)?255:25;ctx.fillStyle=`rgba(${shade},${shade},${shade},${rng()*.035})`;
      ctx.fillRect(rng()*512,rng()*2048,1.2,1.8);
    }
    ctx.fillStyle='#111315';ctx.fillRect(205,0,102,2048);
    for(const y of [346,1024,1702]){
      ctx.save();ctx.translate(256,y);ctx.rotate(Math.PI/2);
      if(logo&&logo.naturalWidth){ctx.drawImage(logo,-125,-36,250,72);}
      else {ctx.fillStyle='#f9f9f9';ctx.textAlign='center';ctx.textBaseline='middle';ctx.font='bold italic 76px Arial';ctx.fillText('EGrip',0,0);}
      ctx.restore();
    }
    gl.bindTexture(gl.TEXTURE_2D,texture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
    gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,c);
    gl.generateMipmap(gl.TEXTURE_2D);
  }
  function resizeCanvas(){
    if(!gl)return;const dpr=Math.min(devicePixelRatio||1,mobile()?1.3:1.8);
    const width=Math.round(innerWidth*dpr),height=Math.round(innerHeight*dpr);
    if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;gl.viewport(0,0,width,height);}
  }
  function setUniforms(){
    const loc=name=>gl.getUniformLocation(program,name);
    const mx=mobile()? .34:1;
    const my=mobile()? (current<.16?1.19: current<.84?-1.1:.40) : 0;
    const size=mobile()?.73:1;
    gl.uniform3f(loc('uRot'),state.rx+dragX,state.ry+dragY+Math.sin(currentTime*.35)*.04,state.rz);
    gl.uniform3f(loc('uTranslate'),state.x*mx,state.y+my+Math.sin(currentTime*1.12)*.09,0);
    gl.uniform1f(loc('uScale'),state.scale*size);
    gl.uniform1f(loc('uBend'),state.bend);
    gl.uniform1f(loc('uCamera'),state.zoom+(mobile()?1.3:0));
    gl.uniform1f(loc('uAspect'),innerWidth/innerHeight);
    gl.uniform1f(loc('uFov'),(mobile()?42:36)*Math.PI/180);
    gl.uniform1f(loc('uTime'),currentTime);
  }
  // Browser-independent animated ribbon renderer. It bends into a loop even when WebGL is disabled.
  function drawFallbackRibbon(){
    if(!fctx)return;
    const dpr=Math.min(devicePixelRatio||1,1.6),w=innerWidth,h=innerHeight;
    if(fallbackCanvas.width!==Math.round(w*dpr)||fallbackCanvas.height!==Math.round(h*dpr)){
      fallbackCanvas.width=Math.round(w*dpr);fallbackCanvas.height=Math.round(h*dpr);
    }
    fctx.setTransform(dpr,0,0,dpr,0,0);
    fctx.clearRect(0,0,w,h);
    const bandOpacity=1-smooth(.2,.9,state.pack);
    if(bandOpacity<.01)return;
    fctx.globalAlpha=bandOpacity;
    const L=5.2, W=.91, bend=state.bend;
    const unitFocal=h/(2*Math.tan((mobile()?42:36)*Math.PI/360));
    function vertex(x,y,z){
      if(bend>.0001){
        const radius=L/(Math.PI*2*bend), angle=y/radius;
        const a=Math.sin(angle),b=Math.cos(angle),depth=z;
        z=radius*(1-b)-radius*(1-Math.cos(Math.PI*bend))*.52+b*depth;
        y=a*radius-a*depth;
      }
      const rx=state.rx, ry=state.ry*.67, rz=state.rz;
      let ty=y*Math.cos(rx)-z*Math.sin(rx),tz=y*Math.sin(rx)+z*Math.cos(rx);
      let tx=x*Math.cos(ry)+tz*Math.sin(ry);tz=-x*Math.sin(ry)+tz*Math.cos(ry);
      x=tx*Math.cos(rz)-ty*Math.sin(rz);y=tx*Math.sin(rz)+ty*Math.cos(rz);z=tz;
      const sc=state.scale*(mobile()?.73:1);
      const px=x*sc+(mobile()?state.x*.3:state.x);
      const py=y*sc+state.y+(mobile()?(current<.16?1.15: current<.84?-1.12:.5):0)+Math.sin(currentTime*1.05)*.055;
      const pz=z*sc;
      const perspective=unitFocal/Math.max(2,state.zoom+(mobile()?1.3:0)-pz);
      return {x:w/2+px*perspective,y:h/2-py*perspective,z:pz};
    }
    function quad(a,b,c,d,fill){
      fctx.beginPath();fctx.moveTo(a.x,a.y);fctx.lineTo(b.x,b.y);fctx.lineTo(d.x,d.y);fctx.lineTo(c.x,c.y);fctx.closePath();
      fctx.fillStyle=fill;fctx.fill(); fctx.strokeStyle=fill; fctx.lineWidth=1.2;fctx.stroke();
    }
    const strips=[];
    const steps=96;
    for(let i=0;i<steps;i++){
      const ya=L*(i/steps-.5),yb=L*((i+1)/steps-.5);
      const a=vertex(-W/2,ya,.035),b=vertex(W/2,ya,.035),c=vertex(-W/2,yb,.035),d=vertex(W/2,yb,.035);
      const as=vertex(-.103,ya,.041),bs=vertex(.103,ya,.041),cs=vertex(-.103,yb,.041),ds=vertex(.103,yb,.041);
      strips.push({a,b,c,d,as,bs,cs,ds,z:(a.z+b.z+c.z+d.z)*.25,index:i});
    }
    strips.sort((a,b)=>a.z-b.z);
    for(const strip of strips){
      const {a,b,c,d,as,bs,cs,ds}=strip;
      // Slightly varied studio illumination gives the shape depth.
      const gr=fctx.createLinearGradient(a.x,a.y,b.x,b.y);
      gr.addColorStop(0,'#777b80');gr.addColorStop(.42,'#bbbdc0');gr.addColorStop(1,'#94979c');
      quad(a,b,c,d,gr);
      quad(as,bs,cs,ds,'#0e1012');
    }
    // Repeated logo lettering stays anchored to the scrolling/deforming band.
    for(const labelY of [-1.67,0,1.67]){
      const center=vertex(0,labelY,.048),above=vertex(0,labelY+.24,.048),right=vertex(.1,labelY,.048);
      const width=Math.hypot(right.x-center.x,right.y-center.y);
      if(width<4)continue;
      const angle=Math.atan2(above.y-center.y,above.x-center.x);
      fctx.save();fctx.translate(center.x,center.y);fctx.rotate(angle);
      fctx.fillStyle='#f4f4f4';fctx.font=`italic 800 ${clamp(width*.66,9,20)}px Arial,sans-serif`;
      fctx.textBaseline='middle';fctx.textAlign='center';fctx.fillText('EGrip',0,0);
      fctx.restore();
    }
    fctx.globalAlpha=1;
  }
  function onScroll(){
    const height=Math.max(1,document.documentElement.scrollHeight-innerHeight);
    progress=clamp(window.scrollY/height);
    fill.style.height=(progress*100).toFixed(2)+'%';
    nav.classList.toggle('scrolled',progress>.008);
  }
  window.addEventListener('scroll',onScroll,{passive:true});onScroll();
  window.addEventListener('resize',()=>{resizeCanvas();onScroll();},{passive:true});
  qs('a[href^="#"]').forEach(a=>a.addEventListener('click',e=>{
    const target=document.querySelector(a.getAttribute('href'));if(!target)return;
    e.preventDefault();target.scrollIntoView({behavior:reduce?'auto':'smooth'});
  }));
  inspectButton.addEventListener('click',()=>{
    inspecting=!inspecting;stage.classList.toggle('interactive',inspecting);$('static-fallback').classList.toggle('interactive',inspecting);
    inspectButton.setAttribute('aria-pressed',String(inspecting));
    inspectHint.hidden=!inspecting;
    inspectButton.innerHTML=inspecting?'AVSLUTA ROTATION <span aria-hidden="true">↗</span>':'ROTERA PRODUKTEN <span aria-hidden="true">↗</span>';
    if(!inspecting)dragX=dragY=0;
  });
  for(const interactiveCanvas of [canvas,fallbackCanvas]){
    interactiveCanvas.addEventListener('pointerdown',e=>{if(!inspecting)return;dragging=true;lastPointerX=e.clientX;lastPointerY=e.clientY;interactiveCanvas.setPointerCapture(e.pointerId);});
    interactiveCanvas.addEventListener('pointermove',e=>{if(!dragging)return;dragY+=(e.clientX-lastPointerX)*.008;dragX+=(e.clientY-lastPointerY)*.008;lastPointerX=e.clientX;lastPointerY=e.clientY;});
    interactiveCanvas.addEventListener('pointerup',()=>dragging=false);
    interactiveCanvas.addEventListener('pointercancel',()=>dragging=false);
  }
  const revealPanel=$('reveal');
  let currentTime=0,last=performance.now();
  function frame(now){
    const dt=Math.min((now-last)/1000,.05);last=now;
    if(!reduce)currentTime+=dt;
    current=lerp(current,progress,reduce?1:1-Math.exp(-dt*5));
    const target=samplePose(current);
    const mix=reduce?1:1-Math.exp(-dt*7);
    for(const k of Object.keys(state))state[k]=lerp(state[k],target[k],mix);
    const packOpacity=smooth(.2,.9,state.pack);
    // Physical packaging uses the real uploaded product photo, never fabricated branding.
    packEl.style.opacity=packOpacity.toFixed(3);
    const pm=mobile() ? .69 : 1;
    packEl.style.transform=`translate3d(${(mobile()?8:state.x*8).toFixed(1)}vw,${(Math.sin(currentTime*.6)*9).toFixed(2)}px,0) rotate(${(Math.sin(currentTime*.43)*1.5).toFixed(2)}deg) scale(${(state.scale*pm).toFixed(3)})`;
    if(webglOK && gl){
      resizeCanvas();
      gl.clearColor(0,0,0,0);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
      gl.useProgram(program);gl.bindBuffer(gl.ARRAY_BUFFER,buffers.buffer);
      setUniforms();gl.uniform1i(gl.getUniformLocation(program,'uSurface'),0);
      gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
      // When packaging is visible, fade the band gracefully in CSS scene.
      canvas.style.opacity=String(clamp(1-packOpacity));
      gl.drawArrays(gl.TRIANGLES,0,buffers.count);
    } else if(!reduce) {
      drawFallbackRibbon();
      const x=mobile()?0:state.x*11;
      fallbackBand.style.transform=`translate3d(${x.toFixed(2)}vw,${(state.y*24+Math.sin(currentTime)*9).toFixed(1)}px,0) rotateZ(${(state.rz*57.3).toFixed(1)}deg) rotateY(${(state.ry*57.3).toFixed(1)}deg) rotateX(${(state.rx*57.3).toFixed(1)}deg) scale(${(state.scale*(mobile()?.75:1)).toFixed(2)})`;
      fallbackBand.style.opacity='0';
      fallbackPack.style.opacity=String(packOpacity);
    }
    const bounds=revealPanel.getBoundingClientRect();
    if(inspecting && (bounds.bottom<0 ||bounds.top>innerHeight))inspectButton.click();
    if(!reduce)requestAnimationFrame(frame);
  }
  if(!reduce)requestAnimationFrame(frame);
  else {packEl.style.opacity='0';$('fallback-band').style.opacity='1';}
  addEventListener('error',e=>{console.warn('EGrip caught runtime issue:',e.message);});
})();

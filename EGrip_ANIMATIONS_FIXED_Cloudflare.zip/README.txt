EGRIP — CLOUDFLARE PAGES DIRECT UPLOAD (ANIMATED VERSION)

INSTRUCTIONS
1. Open Cloudflare > Workers & Pages > your EGrip Pages project > Deployments.
2. Create a new deployment using drag-and-drop.
3. Upload this ZIP directly (or unzip and upload its contents).
4. Deploy and refresh the published website. If you still see the previous version, do a hard refresh (Ctrl+Shift+R).

ANIMATIONS
All required animation code is in local main.js. No Three.js/GSAP/Lenis CDNs are required.
- A 3D band floats, rotates, and bends as you scroll.
- Uses native WebGL on supported browsers and an animated 2D 3D-projection renderer if WebGL is unavailable.
- Headings animate into view; navigation progress updates on scroll.
- Desktop drag-to-rotate is available under 'ROTERA PRODUKTEN'.
- If a visitor requests reduced motion in their device settings, the website respects that setting.

CUSTOMIZING
- Brand visuals and product photo: assets/ folder
- Text/layout: index.html
- Design/responsive settings: style.css
- Animation code: main.js
- Shop drawer: shop.js

PAYMENTS
This is the direct-upload version; Cloudflare Pages drag-and-drop does not deploy the server-side payment/admin code from the full project. Swish is intentionally inactive. The shop button directs customers to EGrip's Instagram.
To accept real Swish payments later, deploy the full project via Git/Wrangler and configure a verified merchant account and backend.

No fake payment confirmations are shown, and no account credentials are included.
